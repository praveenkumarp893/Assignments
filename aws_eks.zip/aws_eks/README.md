# Aws Elastic Kubernetes Services
![status](https://img.shields.io/badge/Status-approved%20(2022--07--10)-success)

Amazon Elastic Kubernetes Service (Amazon EKS) is a managed service that you can use to run Kubernetes on AWS without needing to install, operate, and maintain your own Kubernetes control plane or nodes. Kubernetes is an open-source system for automating the deployment, scaling, and management of containerized applications
This terraform module creates EKS cluster with node groups, Iam role , security groups, cloudwatch log group etc...

## Usage

```bash
$ terraform init
$ terraform plan
$ terraform apply
```

## Example
- With minimum parameters
```hcl
module "eks" {
  source   = "../aws/aws_eks/code"
  location                             = "eu-west-2"
  eks_cluster_name                     = "sample"
  subnet_ids                           = ["subnet-xxx1", "subnet-xxx2", "subnet-xx3"]
}

```
- With maximum parameters
```hcl
module "eks_cluster_1" {
  source   = "../aws/aws_eks/code"
  location = "eu-west-2"                   ## Mandatory
  tags = {                                 ## Optional
    "clusterName" = "Project-A-Cluster-01" ## Optional
    "Created by " = "Abhilash"             ## Optional
    "Env"         = "POC"                  ## Optional
  }
  eks_cluster_name                     = "sample-cluster-02"                                      ## Mandatory
  subnet_ids                           = ["subnet-xxxxxxxx1", "subnet-xxxxxxxx2"] ## Mandatory
  cluster_log_types                    = ["api", "audit", "authenticator", "controllerManager", "scheduler"]
  eks_cluster_version                  = null            ## Optional
  cluster_endpoint_private_access      = true            ## Optional 
  cluster_endpoint_public_access       = true            ##  Optional
  cluster_endpoint_public_access_cidrs = null            ## Optional 
  enable_encryption                    = true            ## Optional 
  service_ipv4_cidr                    = "172.30.0.0/16" ## Optional 
  retention_in_days                    = 7               ## Optional

  ##Node Group
  node_desired_size    = 1              ## Optional 
  node_max_size        = 4              ## Optional 
  node_min_size        = 1              ## Optional  
  node_instance_types  = ["t3a.xlarge"] ## Optional   
  node_disk_size       = 50             ## Optional  
  node_ami_type        = "AL2_x86_64"   ## Optional   
  node_max_unavailable = 1              ## Optional  
  node_capacity_type   = "ON_DEMAND"    ## Optional   

}

module "eks_cluster_1_helm" {
  source                    = "../aws/aws_eks/code/helm" ## Mandatory #source and repo_path are same
  repo_path                 = "../aws/aws_eks/code/helm" ## Mandatory
  create_cluster_autoscaler = true
  create_metrics_server     = true
  eks_cluster               = module.eks_cluster_1.eks_cluster
}


```
## Requirements

| Name  | Version |
| ----- | ------- |
| <a name="requirement_aws"></a> [AWS](#requirement\_aws) | >= 4.13.0 |
| <a name="requirement_terraform"></a> [Terraform](#requirement\_aws) | >= 0.13 |
| <a name="requirement_tls"></a> [tls](#requirement\_tls) | >= 3.3.0 |
| <a name="requirement_helm"></a> [Helm](#requirement\_helm) | >= 2.5.1 |


## Providers

| Name  | Version |
| ----- | ------- |
| <a name="provider_aws"></a> [Aws](#provider\_aws) | >= 4.13.0 |
| <a name="provider_Kubernetes"></a> [Kubernetes](#provider\_Kubernetes) | >= 4.13.0 |
| <a name="provider_tls"></a> [tls](#provider\_tls) | >= 4.13.0 |

## Modules

| Name | Source | Version |
| ---- | ------ | ------- |
| eks | ./modules/aws_kubernetes | NA|
| helm | ./helm | NA| 


# Resources 

| Name | Type |
|----- | ---- |
| aws_cloudwatch_log_group.cloudwatch_log_group | Resource |
| aws_eks_cluster.eks_cluster | Resource |
| aws_iam_role.eks_cluster_role| Resource |
| aws_iam_role.eks_nodegroup_role | Resource|
| aws_iam_role_policy_attachment.AmazonEKSClusterPolicy | Resource|
| aws_iam_role_policy_attachment.AmazonEKSVPCResourceController | Resource|
| aws_iam_role_policy_attachment.AmazonEKSWorkerNodePolicy| Resource |
| aws_iam_role_policy_attachment.AmazonEKS_CNI_Policy| Resource |
| aws_iam_role_policy_attachment.AmazonEC2ContainerRegistryReadOnly| Resource |
| aws_iam_policy.eks-cluster-autoscaler-policy | Resource |
| aws_iam_role_policy_attachment.eks-cluster-autoscaler-policy | Resource | 
| aws_eks_node_group.eks_node_group | Resource |
| aws_security_group.eks_cluster_securitygroup|Resource |
| aws_security_group.eks_cluster_remoteaccess_securitygroup | Resource|
| aws_kms_key.eks_kms_key | Resource|
| aws_kms_alias.eks_kms_alias |Resource |
| aws_subnet.eks_subnet | Data source |


# Inputs

| Name | Description | Type | Default | Required |
| --- | ------ | --- | --- | --- |
| eks_cluster_name | EKS Cluster name | `string` | NA | Yes|
| subnet_ids | List of subnet IDs. Must be in at least two different availability zone | `list(string)` | NA | Yes|
| eks_cluster_version | Kubernetes `<major>.<minor>` version to use for | `string` | NA | No|
| cluster_endpoint_private_access | Indicates whether or not the Amazon EKS private API server endpoint is enabled | `bool` | false | No|
| cluster_endpoint_public_access | Indicates whether or not the Amazon EKS public API | `bool` | true | No |
| cluster_endpoint_public_access_cidrs | List of CIDR blocks which can access the Amazon | `list(string)` | ["0.0.0.0/0"] | No|
| enable_encryption |To define whether cluster required kms key encryption or not | `bool` | false | No |
| service_ipv4_cidr |The CIDR block to assign Kubernetes service IP addresses from | `string` |10.100.0.0/16 or 172.20.0.0/16 | No |
| location| AWS region|`string`| NA | Yes |
| tags| cluster tags - Key-value map of resource tags| `map(string)`| {} | No |
| cluster_log_types| A list of the desired control plane logs to enable | `list(string)`| ["audit", "api","authenticator" ]| No |
| cluster_log_retention_in_days | Specifies the number of days you want to retain log events in the specified log group| `number` | 90 | No |
| node_desired_size| Desired number of worker nodes| `number`| NA | Yes |
| node_max_size | Maximum number of worker nodes | `number`| NA | yes |
| node_min_size| Minimum number of worker nodes| `number`| NA | Yes |
| node_instance_types| List of instance types associated with the EKS| `list(string)`|["t3.medium"] | No |
| node_disk_size| Disk size in GiB for worker nodes| `number`|20 | No |
| node_ami_type| Type of Amazon Machine Image (AMI) associated| `list(string)`| NA | No |
| node_max_unavailable|Desired max number of unavailable worker nodes during node group update | `number`| NA  | No |
| node_capacity_type| Type of capacity associated with eks node group| `string`| "ON_DEMAND"| No |
| node_source_security_group_ids|set of EC2 security Group IDs to allow ssh access from on the worker nodes | `list(string)`| NA | No |
| ec2_ssh_key| SSH key pair name to use to access the worker nodes| `string`| NA | No |

# Outputs
| Name | Desription |
|--- | --- |
|eks_cluster| Details of eks cluster|
|cluster_name| Name of the cluster |
|eks_cluster_version | The Kubernetes server version of the cluster |
| cloudwatch_log_group_name |The name of the log group created in cloudwatch where cluster logs are forwarded to if enabled|

## License

[Mozilla Public License v2.0](https://github.com/hashicorp/terraform/blob/main/LICENSE)

